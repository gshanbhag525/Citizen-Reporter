<?php 
$to_email = 'varsanidarsahak111@gmail.com';
$subject = 'Testing PHP Mail';
$message = 'This mail is sent using the PHP mail function';
$headers = 'From: varsanidarsahak111@gmail.com';
mail($to_email,$subject,$message,$headers);
?>