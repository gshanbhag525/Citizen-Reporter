<?php 
	include('include/checklogin.php');
	include('include/header.php');
	include('include/conn.php');
	?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
	        Images
	        <small>Preview Images</small>
	      </h1>
            <ol class="breadcrumb">
                <li><a href="/City/"><i class="fa fa-dashboard"></i> Home</a></li>
            </ol>
        </section>
        <div class="content">
            <div class="row">
                <div class="col-md-6">
                    <!-- Content Header (Page header) -->
                    <?php
                    $qry=mysqli_query($conn,"SELECT u.Name,u.Email,p.* FROM problems p,user u WHERE p.U_id=u.Id AND p.Status=2 ORDER BY p.Date ASC");
                    while($res=mysqli_fetch_array($qry,MYSQLI_ASSOC))
                    {

                    ?>
                    <div class="box box-widget">
                        <div class="box-header with-border">
                            <div class="user-block">
                                <img class="img-circle" src="dist/img/user1-128x128.jpg" alt="User Image">
                                <span class="username"><a href="#"><?php echo $res['Name']; ?></a></span>
                                <span class="description"><?php $dt=date_create($res['Date']); echo date_format($dt,"d M Y"); ?> |
                                    <i class="fa fa-thumbs-down text-red" style="color:green"></i></span>
                            </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <img class="img-responsive pad" src="http://localhost/City/uploads/<?php echo $res['Image']; ?>" alt="Photo">

                            <p><?php echo $res['Address']; ?></p>
                            <!-- <a href="http://localhost/City/images.php?verify=<?php echo $res['Id'] ?>" class="btn btn-default btn-xs"><i class="fa fa-thumbs-o-up"></i> Send</a>
                            <a href="http://localhost/City/images.php?block=<?php echo $res['Id']; ?>" class="btn btn-default btn-xs"><i class="fa fa-thumbs-o-down"></i> Remove</a> -->
                           <!--  <span class="pull-right text-muted">127 likes - 3 comments</span> -->
                        </div>
                        <!-- /.box-body -->
                        
                        <!-- /.box-footer -->
                    </div>
                    <?php
                	}
                    ?>
                    <!-- /.content -->
                </div>
            </div>
        </div>
    </div>
    <?php include('include/footer.php'); ?>