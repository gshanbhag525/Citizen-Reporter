<?php 
include('include/checklogin.php');
include('include/header.php');
include('include/conn.php');
?>
<div class="content-wrapper">
	<section class="content-header">
    <h1>
      User
      <small>Registered Users</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="/City/"><i class="fa fa-dashboard"></i> Home</a></li>
    </ol>
  </section>
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Users</h3>

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <tbody>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  <?php 
                    $qry=mysqli_query($conn,"SELECT * FROM USER ORDER BY Status DESC");
                    while($res=mysqli_fetch_array($qry,MYSQLI_ASSOC))
                    {
                    ?>
                      <tr>
                        <td>1</td>
                        <td><?php echo $res['Name']; ?></td>
                        <td><?php echo $res['Email']; ?></td>
                        <td><?php echo $res['Address']; ?></td>                        
                        <td><?php echo $res['Phone']; ?></td>
                        <td><?php 
                            if($res['Status']==0)
                            {
                            ?>
                              <span class="label label-warning">pending</span>
                            <?php 
                            } 
                            else if($res['Status']==1)
                            {
                            ?>
                              <span class="label label-success">Approved</span>
                            <?php 
                            }
                            else
                            {
                            ?>
                              <span class="label label-danger">Blocked</span>
                            <?php 
                            }
                            ?>
                        </td>
                        <td>
                          <?php
                          if($res['Status']==0)
                          {
                          ?>
                            <a href="http://localhost/City/user_verify.php?verify=<?php echo $res['Id']; ?>" class="btn btn-success"><i class="fa fa-thumbs-up"></i></a></td>
                          <?php
                          }
                          else if($res['Status']==1)
                          {

                          ?>
                            <a href="http://localhost/City/user_verify.php?block=<?php echo $res['Id']; ?>" class="btn btn-danger"><i class="fa fa-thumbs-down"></i></a></td>
                          <?php
                          }
                          ?>
                      </tr>
                    <?php 
                    } 
                    ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
</div>
<?php include('include/footer.php'); ?>