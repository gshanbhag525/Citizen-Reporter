<?php session_start();
if(!$_SESSION['admin'])
{
	header('Location: http://localhost/City/login.php');
}
?>