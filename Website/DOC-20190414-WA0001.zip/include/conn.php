<?php
$servername = "localhost";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password);

if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
else
{
	$db=mysqli_select_db($conn,'city_reporter');
	if(!$db)
	{
		die('Database Connection Failed : '.mysql_error());
	}
}
?>