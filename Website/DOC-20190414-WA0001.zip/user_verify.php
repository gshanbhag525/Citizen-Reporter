<?php
include('include/conn.php');
if(isset($_GET['block']))
{
	$id=$_GET['block'];
	$sql="UPDATE user SET Status=2 WHERE Id=$id";
	if (mysqli_query($conn,$sql)) 
	{
    	header('Location: http://localhost/City/user.php');
	} 
	else 
	{
    	echo "Error updating record: " . mysqli_error($conn);
	}
}
if(isset($_GET['verify']))
{
	$id=$_GET['verify'];
	$sql="UPDATE user SET Status=1 WHERE Id=$id";
	if (mysqli_query($conn,$sql)) 
	{
    	header('Location: http://localhost/City/user.php');
	} 
	else 
	{
    	echo "Error updating record: " . mysqli_error($conn);
	}
}
?>